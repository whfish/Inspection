package com.demo.inspection;

interface User {

}
